package com.paneer.mlbbipdetect;

import java.util.concurrent.atomic.AtomicLong;

public class IpEntry {
    public final String ip;
    public final int port;
    public final AtomicLong packetCount = new AtomicLong(0);
    public final AtomicLong byteCount = new AtomicLong(0);
    public long lastSeen;
    public boolean isUdp;
    public boolean isCandidate; // high confidence match server

    public IpEntry(String ip, int port, boolean isUdp) {
        this.ip = ip;
        this.port = port;
        this.isUdp = isUdp;
        this.lastSeen = System.currentTimeMillis();
    }

    public void hit(int bytes) {
        packetCount.incrementAndGet();
        byteCount.addAndGet(bytes);
        lastSeen = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        return String.format("%s:%d  pkts=%d  bytes=%d  %s%s",
                ip, port, packetCount.get(), byteCount.get(),
                isUdp ? "UDP" : "TCP",
                isCandidate ? "  [MATCH]" : "");
    }
}
