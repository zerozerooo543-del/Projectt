package com.paneer.mlbbipdetect;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Multi-thread UDP flood toward a target IP:port.
 * Designed for local testing / lag simulation against a known endpoint.
 */
public class UdpFloodEngine {

    public interface Listener {
        void onStats(long packetsSent, long bytesSent, int activeThreads);
        void onError(String msg);
        void onStopped();
    }

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicLong packetsSent = new AtomicLong(0);
    private final AtomicLong bytesSent = new AtomicLong(0);
    private final List<Thread> workers = new ArrayList<>();
    private Listener listener;
    private String targetIp;
    private int targetPort;
    private int threadCount;
    private int packetSize;

    public void setListener(Listener l) {
        this.listener = l;
    }

    public synchronized void start(String ip, int port, int threads, int size) {
        if (running.get()) return;
        this.targetIp = ip;
        this.targetPort = port;
        this.threadCount = Math.max(1, Math.min(threads, 32));
        this.packetSize = Math.max(32, Math.min(size, 1400));
        packetsSent.set(0);
        bytesSent.set(0);
        running.set(true);
        workers.clear();

        for (int i = 0; i < threadCount; i++) {
            Thread t = new Thread(new FloodWorker(i), "udp-flood-" + i);
            t.setPriority(Thread.NORM_PRIORITY + 1);
            workers.add(t);
            t.start();
        }

        // stats reporter
        Thread stats = new Thread(() -> {
            while (running.get()) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    break;
                }
                if (listener != null) {
                    listener.onStats(packetsSent.get(), bytesSent.get(), activeCount());
                }
            }
        }, "udp-flood-stats");
        stats.setDaemon(true);
        stats.start();
    }

    public synchronized void stop() {
        running.set(false);
        for (Thread t : workers) {
            t.interrupt();
        }
        for (Thread t : workers) {
            try { t.join(800); } catch (InterruptedException ignored) {}
        }
        workers.clear();
        if (listener != null) listener.onStopped();
    }

    public boolean isRunning() {
        return running.get();
    }

    private int activeCount() {
        int n = 0;
        for (Thread t : workers) {
            if (t.isAlive()) n++;
        }
        return n;
    }

    private class FloodWorker implements Runnable {
        private final int id;
        private final Random rnd = new Random();

        FloodWorker(int id) {
            this.id = id;
        }

        @Override
        public void run() {
            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket();
                socket.setSoTimeout(0);
                InetAddress addr = InetAddress.getByName(targetIp);
                byte[] payload = new byte[packetSize];
                // fill with semi-random data once, then mutate lightly
                rnd.nextBytes(payload);

                DatagramPacket packet = new DatagramPacket(payload, payload.length, addr, targetPort);

                while (running.get()) {
                    // light mutation so packets are not identical
                    payload[0] = (byte) rnd.nextInt(256);
                    payload[1] = (byte) (id & 0xFF);
                    payload[2] = (byte) (System.nanoTime() & 0xFF);
                    socket.send(packet);
                    packetsSent.incrementAndGet();
                    bytesSent.addAndGet(packetSize);
                }
            } catch (Exception e) {
                if (running.get() && listener != null) {
                    listener.onError("Worker " + id + ": " + e.getMessage());
                }
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (Exception ignored) {}
                }
            }
        }
    }
}
