package com.paneer.mlbbipdetect;

import java.nio.ByteBuffer;

/**
 * Minimal IP / UDP / TCP header parser for VPN tun packets.
 * IPv4 only for speed and reliability on typical mobile paths.
 */
public final class PacketParser {

    public static final class Result {
        public String srcIp;
        public String dstIp;
        public int srcPort;
        public int dstPort;
        public boolean isUdp;
        public boolean isTcp;
        public int payloadLen;
        public boolean valid;
    }

    private final Result result = new Result();

    public Result parse(ByteBuffer packet) {
        result.valid = false;
        result.isUdp = false;
        result.isTcp = false;
        result.payloadLen = 0;

        if (packet.remaining() < 20) return result;

        int start = packet.position();
        byte versionIhl = packet.get(start);
        int version = (versionIhl >> 4) & 0x0F;
        if (version != 4) return result;

        int ihl = (versionIhl & 0x0F) * 4;
        if (ihl < 20 || packet.remaining() < ihl) return result;

        int totalLen = ((packet.get(start + 2) & 0xFF) << 8) | (packet.get(start + 3) & 0xFF);
        int protocol = packet.get(start + 9) & 0xFF;

        result.srcIp = ipToString(packet, start + 12);
        result.dstIp = ipToString(packet, start + 16);

        int transportOffset = start + ihl;
        if (protocol == 17) { // UDP
            if (packet.remaining() < ihl + 8) return result;
            result.srcPort = ((packet.get(transportOffset) & 0xFF) << 8) | (packet.get(transportOffset + 1) & 0xFF);
            result.dstPort = ((packet.get(transportOffset + 2) & 0xFF) << 8) | (packet.get(transportOffset + 3) & 0xFF);
            int udpLen = ((packet.get(transportOffset + 4) & 0xFF) << 8) | (packet.get(transportOffset + 5) & 0xFF);
            result.payloadLen = Math.max(0, udpLen - 8);
            result.isUdp = true;
            result.valid = true;
        } else if (protocol == 6) { // TCP
            if (packet.remaining() < ihl + 14) return result;
            result.srcPort = ((packet.get(transportOffset) & 0xFF) << 8) | (packet.get(transportOffset + 1) & 0xFF);
            result.dstPort = ((packet.get(transportOffset + 2) & 0xFF) << 8) | (packet.get(transportOffset + 3) & 0xFF);
            int dataOffset = ((packet.get(transportOffset + 12) & 0xF0) >> 4) * 4;
            result.payloadLen = Math.max(0, totalLen - ihl - dataOffset);
            result.isTcp = true;
            result.valid = true;
        }
        return result;
    }

    private static String ipToString(ByteBuffer buf, int offset) {
        return (buf.get(offset) & 0xFF) + "." +
                (buf.get(offset + 1) & 0xFF) + "." +
                (buf.get(offset + 2) & 0xFF) + "." +
                (buf.get(offset + 3) & 0xFF);
    }
}
