package com.paneer.mlbbipdetect;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Local VPN service that routes device traffic through a tun interface.
 * Parses outbound packets, extracts remote IP:port for MLBB ranges,
 * and forwards packets so the game continues to work.
 *
 * No root required. User must approve VPN permission once.
 */
public class VpnCaptureService extends VpnService {

    public static final String ACTION_START = "com.paneer.mlbbipdetect.START_CAPTURE";
    public static final String ACTION_STOP = "com.paneer.mlbbipdetect.STOP_CAPTURE";
    public static final String BROADCAST_STATUS = "com.paneer.mlbbipdetect.CAPTURE_STATUS";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_MSG = "msg";

    private static final String TAG = "VpnCapture";
    private static final String CHANNEL_ID = "mlbb_capture";
    private static final int NOTIF_ID = 1001;

    public static final IpStore STORE = new IpStore();

    private ParcelFileDescriptor vpnInterface;
    private Thread captureThread;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final PacketParser parser = new PacketParser();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            startCapture();
        } else if (ACTION_STOP.equals(action)) {
            stopCapture();
            stopSelf();
        }
        return START_STICKY;
    }

    private void startCapture() {
        if (running.get()) return;

        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification("Capturing…"));

        try {
            Builder builder = new Builder(this)
                    .setSession("MLBB IP Capture")
                    .addAddress("10.0.0.2", 32)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("8.8.8.8")
                    .setMtu(1500)
                    .setBlocking(true);

            // Only capture traffic from MLBB package if possible; otherwise all
            try {
                builder.addAllowedApplication("com.mobile.legends");
            } catch (Exception ignored) {
                // package not installed or not allowed → capture all
            }
            try {
                // some regions use different package names
                builder.addAllowedApplication("com.mobilelegends.hwag");
            } catch (Exception ignored) {}

            vpnInterface = builder.establish();
            if (vpnInterface == null) {
                broadcastStatus("ERROR", "VPN establish failed (permission?)");
                stopForeground(true);
                stopSelf();
                return;
            }

            running.set(true);
            STORE.clear();
            captureThread = new Thread(this::captureLoop, "vpn-capture");
            captureThread.start();
            broadcastStatus("RUNNING", "Capture active. Open MLBB and enter a match.");
        } catch (Exception e) {
            Log.e(TAG, "startCapture", e);
            broadcastStatus("ERROR", e.getMessage());
            stopForeground(true);
            stopSelf();
        }
    }

    private void captureLoop() {
        FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
        FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
        ByteBuffer packet = ByteBuffer.allocate(32767);

        try {
            while (running.get()) {
                packet.clear();
                int length = in.read(packet.array());
                if (length <= 0) {
                    Thread.sleep(1);
                    continue;
                }
                packet.limit(length);

                PacketParser.Result r = parser.parse(packet);
                if (r.valid) {
                    // record remote endpoint (destination of outbound, source of inbound)
                    // for game traffic we care about remote server
                    String remoteIp = r.dstIp;
                    int remotePort = r.dstPort;
                    // if packet is inbound (src is remote), swap
                    if (isLocal(r.dstIp)) {
                        remoteIp = r.srcIp;
                        remotePort = r.srcPort;
                    }
                    STORE.record(remoteIp, remotePort, r.isUdp, r.payloadLen);
                }

                // forward packet back into the tunnel so connectivity works
                out.write(packet.array(), 0, length);
            }
        } catch (IOException | InterruptedException e) {
            if (running.get()) {
                Log.e(TAG, "captureLoop end", e);
            }
        } finally {
            try { in.close(); } catch (Exception ignored) {}
            try { out.close(); } catch (Exception ignored) {}
        }
    }

    private boolean isLocal(String ip) {
        return ip.startsWith("10.0.0.") || ip.startsWith("127.") || ip.equals("0.0.0.0");
    }

    private void stopCapture() {
        running.set(false);
        if (captureThread != null) {
            captureThread.interrupt();
            try { captureThread.join(1500); } catch (InterruptedException ignored) {}
            captureThread = null;
        }
        if (vpnInterface != null) {
            try { vpnInterface.close(); } catch (IOException ignored) {}
            vpnInterface = null;
        }
        stopForeground(true);
        broadcastStatus("STOPPED", "Capture stopped.");
    }

    private void broadcastStatus(String status, String msg) {
        Intent i = new Intent(BROADCAST_STATUS);
        i.putExtra(EXTRA_STATUS, status);
        i.putExtra(EXTRA_MSG, msg);
        i.setPackage(getPackageName());
        sendBroadcast(i);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "MLBB Capture", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Local VPN packet capture");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.vpn_notification_title))
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        stopCapture();
        super.onDestroy();
    }

    @Override
    public void onRevoke() {
        stopCapture();
        stopSelf();
    }
}
